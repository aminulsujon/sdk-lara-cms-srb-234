<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <url>
        <loc>{{ 'https://demo.dainikcoxsbazar.com/' }}</loc>
    </url>
    @foreach($contents as $content)
        <url>
            <loc>{{'https://demo.dainikcoxsbazar.com/'.$content->pagelink.'/'}}</loc>
        </url>
    @endforeach
</urlset>