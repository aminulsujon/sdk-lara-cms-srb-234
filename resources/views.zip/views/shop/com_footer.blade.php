<footer>
  <div class="footerbg d-print-none">
    <div class="container">
      <div class="row">
        <div class="col-lg-4 col-md-5 col-12 border-right-inner-forFooter">
          <div class="DFLogo mb-4">
            <a href="/">
              <img src="images/logo.jpg" alt="" width="300" class="p-2 rounded bg-white">
            </a>
          </div>
        </div>
        <div class="col-lg-5 col-md-5 col-12 border-right-inner-forFooter">
          <h5>যোগাযোগ</h5>
          <div class="Info">
            <div>হোটেল কোহিনুর, শহীদ স্বরণী, কক্সবাজার-৪৭০০, </div>
            <div>ফোন: ০৩৪১৬২৭৯৪, ০১৮১৬৩৬২৭৪১, ০১৮১৯৩৪৫৭৭৫</div>
          </div>
        </div>
        <div class="col-lg-2 col-md-2 col-12 smm">
          <h5>অনুসরণ করুন</h5>
          <div class="address">
            @include('blog.com_social')
          </div>
        </div>
      </div>
    </div>
    <div class="editorial mt-4">
      <h5><span>সম্পাদক:</span> ফাতেমা জাহান</h5>
      <h5><span>পরিচালনা সম্পাদক:</span> মোহাম্মদ মুজিবুল ইসলাম</h5>
      <h5><span>বার্তা সম্পাদক:</span> মোহাম্মদ নজিবুল ইসলাম</h5>
    </div>
  </div>
  <div class="">
    <div class="container">
      <div class="row">
        <div class="col-sm-12 text-center">
          <p>
            @if(!empty($websettings['cms_web_copyright'])) {{ $websettings['cms_web_copyright'] }} @else All rights reserved @endif | 
          </p>
        </div>
        @if(!empty($websettings['cms_developer_credit']))
          <div class="col-sm-12 text-center dev-credit">
            <p>
              {!! $websettings['cms_developer_credit'] !!}
            </p>
          </div>
        @endif
        
      </div>
    </div>
  </div>
</footer>
<style>
  footer .header-social li{
    display: inline;
    padding: 0 10px
  }
  .footerbg {
    border-top: 1px solid #000;
    padding: 20px 0 10px 0
  }
  footer .editorial {
    display: flex;
    justify-content: center;
    background: #ddd;
    align-items: center;
}
footer .editorial h5 {
    padding: 20px 20px;
    border-right: 1px solid #999;
    margin-bottom: 0;
    font-weight: bold;
}
  footer .editorial h5:last-child{
    border-right: 0
  }
footer .dev-credit a{
    font-size: 90%;
    color: #666;
    margin-top: -10px;
    margin-bottom: 10px;
}
  
@media (max-width: 576px) {
  footer .editorial {
    display: block;
  }
      footer .editorial h5 {
        display: block;
        margin-right: 0;
        border-right: 0;
        padding: 10px 20px;
        border-top: 1px solid #c3c3c3;
    }
        .smm {
        border-top: 1px solid #ddd;
        margin-top: 15px;
        padding-top: 15px;
    }
}
</style>