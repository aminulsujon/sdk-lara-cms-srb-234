<!DOCTYPE html>
<html lang="en"><head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Favicon -->
    <link rel="icon" href="images/favicon.ico">

    @yield('social')

    <!-- Core Stylesheet -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/ticker-style.css">
    <link rel="stylesheet" href="css/slicknav.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/slick.css">
    <link rel="stylesheet" href="css/nice-select.css">

    <!-- Core Stylesheet -->
    <link rel="stylesheet" href="css/style.css?v=102">

    <!-- Responsive Stylesheet -->
    <link rel="stylesheet" href="css/responsive.css">
    @include('blog.layouts.script_body')
    @include('blog.layouts.script_google')
    @include('blog.layouts.script_pixel')
</head>

<body class="light-version">
    @include('blog.layouts.script_body')
    @php
    function enToBnDateTime($datetime){
        $en = ['0','1','2','3','4','5','6','7','8','9','AM','PM','Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
        $bn = ['০','১','২','৩','৪','৫','৬','৭','৮','৯','এএম','পিএম','রবিবার','সোমবার','মঙ্গলবার','বুধবার','বৃহস্পতিবার','শুক্রবার','শনিবার','জানুয়ারি','ফেব্রুয়ারি','মার্চ','এপ্রিল','মে','জুন','জুলাই','আগস্ট','সেপ্টেম্বর','অক্টোবর','নভেম্বর','ডিসেম্বর'];
        return str_replace($en, $bn, $datetime);
    }
    @endphp
    <header>
        <!-- Header Start -->
       <div class="header-area">
            <div class="main-header ">
                <div class="header-top d-none">
                   <div class="container">
                       <div class="col-xl-12">
                            <div class="row d-flex justify-content-between align-items-center">
                                <div class="header-info-left">
                                    <ul>     
                                        <li class="p-2"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24">
                                          <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 
                                                  0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 
                                                  2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
                                        </svg>
                                         বাংলাদেশ </li>
                                        <li><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24">
                                        <path d="M19 4h-1V2h-2v2H8V2H6v2H5c-1.1 
                                                0-2 .9-2 2v14c0 1.1.9 2 2 
                                                2h14c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 
                                                16H5V9h14v11z"/>
                                      </svg>
                                      {{ enToBnDateTime(date('l, d M Y'))}}</li>
                                    </ul>
                                </div>
                                <div class="header-info-right">
                                    @include('blog.com_social')
                                </div>
                            </div>
                       </div>
                   </div>
                </div>
                <style>.sp{font-size:90%;color:#002e5b}
                  .media-body{
                      margin-left: 10px;
                      line-height: 21px;
                      height: 41px;
                      overflow: hidden;
                  }
                  .media img{border-radius:5px;}
                </style>
                <div class="header-mid d-none d-md-block">
                   <div class="container">
                        <div class="row d-flex align-items-center">
                            <!-- Logo -->
                            <div class="col-xl-3 col-lg-3 col-md-3">
                                <div class="logo py-4-">
                                    <a href="{{ $websettings['cms_url'] }}"><img src="images/logo.jpg" alt="logo" height="80">
                                      <span class="d-none">{{ $websettings['cms_sitename'] }}</span>
                                    </a>
                                </div>
                            </div>
                            
                            <div class="col-1">

                            </div>

                            <div class="col-md-6">
                              <div class="row">
                                @if(!empty($spotlight) && count($spotlight->contents) > 0)
                                
                                  @foreach($spotlight->contents->take(2) as $content)
                                    <div class="col-6">
                                      <div class="media">
                                        <a href="{{ $content->slug }}">
                                          @foreach ($content->upload as $item)  
                                            <img class="float-start" width="70" src="{{ asset( 'images/uploads/thumb/'.$item['file']) }}" alt="{{ $item['name'] }}">  
                                            @break
                                          @endforeach
                                        </a>
                                        <div class="media-body" style="margin-left: 10px">
                                          <a class="sp" href="{{ $content->slug }}">{{$content->name }}</a>
                                        </div>
                                      </div>
                                    </div>
                                  @endforeach
                                @else
                                  <img src="images/header_card.jpg" alt="">
                                @endif
                              </div>
                            </div>

                            <div class="col-1">
                                
                            </div>
                        </div>
                   </div>
                </div>
                <?php
                $menus = [];
                $i = 1;
                foreach($tags as $tag){
                  if(empty($tag->parent)){
                    $menus[$tag->id]['id']= $tag->id;
                    $menus[$tag->id]['title']= $tag->title;
                    $menus[$tag->id]['linkto']= $tag->linkto;
                    $menus[$tag->id]['linkUrl']= $tag->linkUrl;
                    $menus[$tag->id]['status']= $tag->status;
                    $menus[$tag->id]['sequence']= $tag->sequence;
                  }else{
                    $child[$tag->parent][$i]['id'] = $tag->id;
                    $child[$tag->parent][$i]['title'] = $tag->title;
                    $child[$tag->parent][$i]['linkto'] = $tag->linkto;
                    $child[$tag->parent][$i]['linkUrl'] = $tag->linkUrl;
                    $child[$tag->parent][$i]['status'] = $tag->status;
                    $child[$tag->parent][$i]['sequence'] = $tag->sequence;
                    $i++;
                  }
                }
                // dd($menus);
                ?>
               <div class="header-bottom header-sticky">
                    <div class="container">
                        <div class="row align-items-center">
                            <div class="col-xl-12 col-lg-12 col-md-12 header-flex">
                                <!-- sticky -->
                                <div class="sticky-logo">
                                    <a href="{{ $websettings['cms_url'] }}"><img src="images/logocx.jpg" alt=""></a>
                                </div>
                                <!-- Main-menu -->
                                <div class="main-menu d-none d-md-block">
                                    <nav>                  
                                        <ul id="navigation">    
                                            <li><a href="{{ $websettings['cms_url'] }}latest">সর্বশেষ</a></li>
                                            @foreach ($menus as $key => $value)
                                              <li>
                                                <a href="{{ $value['linkto'] }}">{{ $value['title'] }}</a>
                                                @if(!empty($child[$key]))
                                                  <ul class="submenu">
                                                  @foreach ($child[$key] as $ke => $val)
                                                    <li><a href="{{ $val['linkto'] }}">{{ $val['title'] }}</a></li>
                                                  @endforeach
                                                  </ul>
                                                @endif
                                              </li>
                                            @endforeach
                                        </ul>
                                    </nav>
                                </div>
                            </div>             
                  
                            <!-- Mobile Menu -->
                            <div class="col-12">
                                <div class="mobile_menu d-block d-md-none"></div>
                            </div>
                        </div>
                    </div>
               </div>
            </div>
       </div>
        <!-- Header End -->
    </header>

    <!-- Trending Area Start -->
    <div class="trending-area fix mt-4">
      <div class="container">
        <div class="trending-main">
          @if (!empty($websettings['cms_news_ticker_status']))
            @include('blog.com_trending')
          @endif
        </div>
      </div>
    </div>

    @include('blog.ads.header')

    @yield('content')

    @include('blog.ads.footer')
    
    @include('blog.com_footer')

    <!-- All JS Custom Plugins Link Here here -->
    <script src="js/modernizr-3.5.0.min.js"></script>
    <!-- Jquery, Popper, Bootstrap -->
    <script src="js/jquery-1.12.4.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <!-- Jquery Mobile Menu -->
    <script src="js/jquery.slicknav.min.js"></script>

    <!-- Jquery Slick , Owl-Carousel Plugins -->
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/slick.min.js"></script>
    <!-- Date Picker -->
    <script src="js/gijgo.min.js"></script>
    <!-- One Page, Animated-HeadLin -->
    <script src="js/wow.min.js"></script>
    <script src="js/animated.headline.js"></script>
    <script src="js/jquery.magnific-popup.js"></script>

    <!-- Breaking New Pluging -->
    <script src="js/jquery.ticker.js"></script>
    <script src="js/site.js"></script>

    <!-- Scrollup, nice-select, sticky -->
    <script src="js/jquery.scrollUp.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    
    <!-- contact js -->
    <script src="js/contact.js"></script>
    <script src="js/jquery.form.js"></script>
    <script src="js/jquery.validate.min.js"></script>
    <script src="js/mail-script.js"></script>
    <script src="js/jquery.ajaxchimp.min.js"></script>
    
    <!-- Jquery Plugins, main Jquery -->	
    <script src="js/plugins.js"></script>
    <script src="js/main.js"></script>

    @include('blog.layouts.script_footer')
</body>
</html>