@if(!empty($tops))
<div class="trending-area fix mt-4">
    <div class="container">
        <div class="trending-main">
                <div class="row">
                    <div class="col-lg-8">
                        <!-- Trending Top -->
                        <div class="trending-top mb-30">
                            <div class="trend-top-img">
                                @foreach ($tops->Contents[0]['upload'] as $item)
                                    <a href="{{ $tops->Contents[0]['slug'] }}">
                                        <img class="img-fluid" src="{{ asset( 'images/uploads/large/'.$item['file']) }}" alt="{{ $item['name'] }}">  
                                    </a>
                                    @break
                                @endforeach
                                <div class="trend-top-cap rounded-bottom">
                                    <h2><a href="{{ $tops->Contents[0]['slug'] }}">{{ $tops->Contents[0]['name'] }}</a></h2>
                                </div>
                            </div>
                        </div>
                        <!-- Trending Bottom -->
                        <div class="trending-bottom">
                            <div class="row">
                                @foreach($tops->Contents->skip(1)->take(6) as $content)
                                    <div class="col-6 col-md-4">
                                        <div class="single-bottom mb-35">
                                            <div class="trend-bottom-img mb-30">
                                                @foreach ($content['upload'] as $item)
                                                    <a href="{{ $content['slug'] }}">
                                                        <img class="img-fluid" src="{{ asset( 'images/uploads/large/'.$item['file']) }}" alt="{{ $item['name'] }}">  
                                                    </a>
                                                    @break
                                                @endforeach
                                            </div>
                                            <div class="trend-bottom-cap">
                                                <h4><a href="{{ $content->slug }}">{{ $content->name }}</a></h4>
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    </div>

                    <!-- Right content -->
                    <div class="col-lg-4">
                        @foreach($tops->Contents->skip(7)->take(12) as $content)
                            <div class="row mt-4">
                                <div class="col-4">
                                    @foreach ($content['upload'] as $item)
                                        <a href="{{ $content['slug'] }}">
                                            <img 
                                            class="rounded"
                                                src="{{ asset( 'images/uploads/thumb/'.$item['file']) }}"
                                                alt="{{ $item['name'] }}"
                                            >  
                                        </a>
                                        @break
                                    @endforeach
                                </div>
                                <div class="col-8">
                                    <a href="{{ $content->slug }}">{{ $content->name }}</a>
                                </div>
                            </div>
                            
                        @endforeach
                        @if(!empty($websettings['cms_ads_status']))
                            <div class="mt-4">
                                @include('blog.ads.300x250',['width'=>300,'height'=>250,'position'=>'Top R1','text'=>'Advertisment 300x250'])
                            </div>
                        @endif
                    </div>
                </div>
        </div>
    </div>
</div>

@endif