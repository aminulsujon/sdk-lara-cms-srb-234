<div class="bg-white border-bottom">
    <div class="container py-2">
        <div class="w-100">
            <div class="row">
                <div class="col-3">
                    <div class="mb-2">
                        <a href="/" class="text-dark ms-3 d-none d-md-inline">
                            <svg xmlns="http://www.w3.org/2000/svg"  viewBox="0 0 50 50" width="20px" height="20px"><path d="M 24.962891 1.0546875 A 1.0001 1.0001 0 0 0 24.384766 1.2636719 L 1.3847656 19.210938 A 1.0005659 1.0005659 0 0 0 2.6152344 20.789062 L 4 19.708984 L 4 46 A 1.0001 1.0001 0 0 0 5 47 L 18.832031 47 A 1.0001 1.0001 0 0 0 19.158203 47 L 30.832031 47 A 1.0001 1.0001 0 0 0 31.158203 47 L 45 47 A 1.0001 1.0001 0 0 0 46 46 L 46 19.708984 L 47.384766 20.789062 A 1.0005657 1.0005657 0 1 0 48.615234 19.210938 L 41 13.269531 L 41 6 L 35 6 L 35 8.5859375 L 25.615234 1.2636719 A 1.0001 1.0001 0 0 0 24.962891 1.0546875 z M 25 3.3222656 L 44 18.148438 L 44 45 L 32 45 L 32 26 L 18 26 L 18 45 L 6 45 L 6 18.148438 L 25 3.3222656 z M 37 8 L 39 8 L 39 11.708984 L 37 10.146484 L 37 8 z M 20 28 L 30 28 L 30 45 L 20 45 L 20 28 z"/></svg>
                            {{-- id="openMenu" <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"
                                fill="none" stroke="currentColor" stroke-width="2"
                                stroke-linecap="round" stroke-linejoin="round">
                                <title>Menu</title>
                                <line x1="3" y1="6" x2="21" y2="6"></line>
                                <line x1="3" y1="12" x2="21" y2="12"></line>
                                <line x1="3" y1="18" x2="21" y2="18"></line>
                            </svg> --}}
                        </a>
                        <a href="javascript:void(0);" id="openSearch" class="text-dark pl-2">
                            <!-- Outline search icon (24x24) -->
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" role="img">
                                <title>Search</title>
                                <circle cx="11" cy="11" r="7"></circle>
                                <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                            </svg>
                        </a>
                    </div>
                    <span class="d-none d-md-block">
                    {{ enToBnDateTime(date('l, d M Y')) }}
                    </span>
                </div>
                <div class="col-6 text-center">
                    <a href="{{ $websettings['cms_url'] }}">
                        <img src="images/logo.jpg" alt="logo" class="img-fluid logo-gfx">
                        <span class="d-none">{{ $websettings['cms_sitename'] }}</span>
                    </a>
                </div>
                <div class="col-3 d-none d-md-block">
                    @include($websettings['cms_layout'].'.com_social')
                </div>
            </div>
            
        </div>
    </div>
</div>
@include($websettings['cms_layout'].'.com_search')