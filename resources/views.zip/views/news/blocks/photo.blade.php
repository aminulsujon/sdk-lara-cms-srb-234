<!-- Photo Gallery Section -->
<section class="container mb-5">
    <div class="section-tittle mb-30">
        <h3><span>ফটো গ্যালারি</span></h3>
    </div>

    <div class="row">

        <!-- Main Photo -->
        <div class="col-lg-8 mb-4">
            @if($home_photos->isNotEmpty())
            <div class="shadow rounded">
                <img 
                    id="mainPhoto"
                    src="{{ asset('uploads/gallery/' . $home_photos[0]->photo) }}" 
                    alt="{{ $home_photos[0]->title }}"
                    class="img-fluid rounded"
                    style="width: 100%; height: 450px; object-fit: cover;">
            </div>

            <!-- Photo Title -->
            <div class="mt-3">
                <h4 class="fw-bold" id="mainPhotoTitle">{{ $home_photos[0]->title }}</h4>
            </div>
            @endif
        </div>

        <!-- Related Photos Sidebar -->
        <div class="col-lg-4 mt-4 mt-sm-0">
            @foreach($home_photos->skip(1) as $photo)
            <div class="row mb-3">
                <div class="col-5">
                    <a href="javascript:void(0);"
                       class="photo-thumb"
                       data-photo="{{ asset('uploads/gallery/' . $photo->photo) }}"
                       data-title="{{ $photo->title }}">
                        <img 
                            src="{{ asset('uploads/gallery/' . $photo->photo) }}" 
                            class="rounded shadow-sm me-3"
                            alt="{{ $photo->title }}"
                            style="width: 150px; height: 90px; object-fit: cover;">
                    </a>
                </div>
                <div class="col-7 d-flex align-items-center">
                    <a href="javascript:void(0);" 
                       class="photo-thumb text-dark text-decoration-none"
                       data-photo="{{ asset('uploads/gallery/' . $photo->photo) }}"
                       data-title="{{ $photo->title }}">
                       {{ $photo->title }}
                    </a>
                </div>
            </div>
            @endforeach
        </div>

    </div>
</section>

<!-- Script for dynamic photo switching -->
<script>
  document.addEventListener("DOMContentLoaded", function () {
    const mainPhoto = document.getElementById("mainPhoto");
    const mainTitle = document.getElementById("mainPhotoTitle");

    document.querySelectorAll(".photo-thumb").forEach(item => {
      item.addEventListener("click", function () {
        const photoSrc = this.getAttribute("data-photo");
        const photoTitle = this.getAttribute("data-title");

        // Update main photo and title
        mainPhoto.src = photoSrc;
        mainTitle.textContent = photoTitle;

        // Optional smooth scroll
        mainPhoto.scrollIntoView({ behavior: "smooth", block: "start" });
      });
    });
  });
</script>
