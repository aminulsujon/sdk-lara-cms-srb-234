@extends($websettings['cms_layout'].'.layouts.app')

@section('social')
	<meta name="robots" content="{{ $pagesetting->meta_robots ?? 'index,allow' }}" />
    <title>{{ $pagesetting->meta_title ?? $websettings['cms_sitename'] ?? 'Title' }}</title>
    <meta name="description" content="{{ $pagesetting->meta_description ?? $websettings['cms_sitename'] ?? 'Description' }}" />
    <link rel="canonical" href="{{ $websettings['cms_url'] ?? 'URL' }}/" />
    <meta property="site_name" content="{{ $websettings['cms_sitename'] ?? 'Site Name' }}" />
    <meta property="og:url" content="{{ $websettings['cms_url'] ?? 'URL' }}/" />
    <meta property="og:title" content="{{ $pagesetting->meta_title ?? $websettings['cms_sitename'] ?? 'Title' }}" />
    <meta property="og:description" content="{{ $pagesetting->meta_description ?? $websettings['cms_sitename'] ?? 'Description' }}" />
    <meta property="og:keywords" content="{{ $pagesetting->meta_keywords ?? $websettings['cms_sitename'] ?? 'Keywords' }}" />
    <meta property="og:image" content="{{ $websettings['cms_assets'] ?? '' }}images/uploads/large/{{ $pagesetting['meta_image'] ?? '' }}" />
    <meta name="twitter:card" content="summary" />
    <meta name="twitter:site" content="{{ $websettings['cms_sitename'] ?? 'Sitename' }}" />
    <meta name="twitter:creator" content="@ {{ $websettings['cms_author'] ?? 'Creator' }}" />
    <meta property="twitter:url" content="@ {{ $websettings['cms_assets'] ?? 'URL' }}/" />
    <meta property="twitter:title" content="{{ $pagesetting->meta_title ?? $websettings['cms_sitename'] ?? 'Title' }}" />
    <meta property="twitter:description" content="{{ $pagesetting->meta_description ?? $websettings['cms_sitename'] ?? 'Description' }}" />
    <meta property="twitter:keywords" content="{{ $pagesetting->meta_keywords ?? $websettings['cms_sitename'] ?? 'Keywords' }}" />
    <meta property="twitter:image" content="{{ $websettings['cms_assets'] ?? '' }}images/uploads/large/{{ $pagesetting['meta_image'] ?? '' }}" />
@endsection

@section('content')
<main>
    
    <!-- Trending Area Start -->
    @if(!empty($websettings['cms_home_events']) && $websettings['cms_home_events']==1)
        @include('blog.com_event')
    @endif
    <!-- Trending Area End -->

    <!-- Top Area Start -->
    @include('blog.com_top')
    <!--   Top start -->

    <!--   Weekly-News start -->
    @include('blog.com_week2')
    
    @include('blog.ads.middle') 
    <!-- End Weekly-News -->
   <!-- Whats New Start -->
    <section class="whats-news-area pb-20">
        @if(!empty($leadcats) && count($leadcats) > 0)
            @foreach($leadcats as $leads)
                @if(!empty($leads->Contents) && count($leads->Contents) > 0)
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="whats-news-caption">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="section-tittle mb-30">
                                            <h3>
                                                <a href="{{ url($leads->linkto) }}">
                                                    {{ $leads->title }}  
                                                </a>
                                            </h3>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    @foreach($leads->Contents as $content)
                                        <div class="col-6 col-lg-4 col-md-3">
                                            <div class="single-what-news mb-100">
                                                <div class="what-img">
                                                    @foreach ($content['upload'] as $item)
                                                        <a href="{{ $content['slug'] }}">
                                                            <img class="img-fluid" src="{{ asset( 'images/uploads/large/'.$item['file']) }}" alt="{{ $item['name'] }}">  
                                                        </a>
                                                        @break
                                                    @endforeach
                                                </div>
                                                <div class="what-cap">
                                                    <h4><a href="{{ $content['slug'] }}">{{ $content['name'] }}</a></h4>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                            </div>
                        </div>
                    </div>
                    @include('blog.ads.middlecategory') 
                </div>
                
                @endif
            @endforeach
        @endif
    </section>

    <!-- Whats New End -->
    <!--   Weekly2-News start -->
    {{-- @include('blog.com_week2') --}}
           
    <!-- End Weekly-News -->
    
    <!-- Start Youtube -->
    @include('blog.home_video')
    <!-- End Start youtube -->

    <!-- End pagination  -->
    </main>

@endsection