<!-- News Video Section (YouTube style simplified) -->
<section class="container mb-5">
    <div class="section-tittle mb-30">
            <h3>
                <span>ভিডিও</span>
            </h3>
        </div>
  <div class="row">

    <!-- Main Video & Details -->
    <div class="col-lg-8 mb-4">
        @if($home_videos->isNotEmpty())
          <!-- Main Video -->
          <div class="ratio ratio-16x9 shadow rounded">
            <iframe 
              id="mainVideo"
              src="https://www.youtube.com/embed/{{ $home_videos[0]->youtubevideo }}" 
              title="{{ $home_videos[0]->name }}"
              width="100%" height="400px"
              allowfullscreen>
            </iframe>
          </div>

          <!-- Video Title -->
          <div class="mt-3">
            <h4 class="fw-bold" id="mainVideoTitle">{{ $home_videos[0]->name }}</h4>
          </div>
        @endif
    </div>

    <!-- Related Videos (sidebar) -->
    <div class="col-lg-4 mt-4 mt-sm-0">
      @foreach($home_videos->skip(1) as $video)
        <div class="row mb-3">
          <!-- Thumbnail -->
          <div class="col-5">
          <a href="javascript:void(0);" 
             class="video-thumb d-flex"
             data-video="{{ $video->youtubevideo }}"
             data-title="{{ $video->name }}">
            <img src="https://img.youtube.com/vi/{{ $video->youtubevideo }}/mqdefault.jpg" 
                 class="rounded shadow-sm me-3" 
                 alt="{{ $video->name }}" 
                 style="width: 150px; height: auto;">
          </a>
          </div>
          <!-- Video Details -->
          <div class="col-7">
            <a href="javascript:void(0);" 
               class="video-thumb text-dark text-decoration-none"
               data-video="{{ $video->youtubevideo }}"
               data-title="{{ $video->name }}">{{ $video->name }}
            </a>
          </div>
        </div>
      @endforeach
    </div>
    
  </div>
</section>

<!-- Script for dynamic video switching -->
<script>
  document.addEventListener("DOMContentLoaded", function () {
    const mainVideo = document.getElementById("mainVideo");
    const mainTitle = document.getElementById("mainVideoTitle");

    document.querySelectorAll(".video-thumb").forEach(item => {
      item.addEventListener("click", function () {
        const videoId = this.getAttribute("data-video");
        const title = this.getAttribute("data-title");

        // Update iframe and title
        mainVideo.src = "https://www.youtube.com/embed/" + videoId;
        mainTitle.textContent = title;

        // Smooth scroll to video (optional)
        mainVideo.scrollIntoView({ behavior: "smooth", block: "start" });
      });
    });
  });
</script>
