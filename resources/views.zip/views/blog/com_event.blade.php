@if(!empty($home_events) && count($home_events['Contents']) > 0)
<section class="trending-section">
  <h2 class="trending-header mt-4 mb-4">{{ $home_events['title'] }}</h2>
  <div class="container">
    <div class="row">
      <!-- News Card 1 -->
      @foreach($home_events['Contents']->take(1) as $event)
      <div class="col-md-4 mb-4 ">
        <div class="news-card">
            @foreach ($event['upload'] as $item)
                <a href="{{ $event['slug'] }}">
                    <img class="img-fluid" src="{{ asset( 'images/uploads/large/'.$item['file']) }}" alt="{{ $item['name'] }}">  
                </a>
                @break
            @endforeach
            <div class="news-card-body">
                <h5 class="card-title">{{ $event['name'] }}</h5>
            </div>
        </div>
        </div>
        @endforeach
        <div class="col-md-4 mb-4 ">
                @foreach($home_events['Contents']->skip(1)->take(3) as $content)
                    <div class="mb-4">
                        <div class="row">
                            <div class="col-4 col-md-4">
                                @foreach ($content['upload'] as $item)
                                    <a href="{{ $content['slug'] }}">
                                        <img class="img-fluid" src="{{ asset( 'images/uploads/thumb/'.$item['file']) }}" alt="{{ $item['name'] }}">  
                                    </a>
                                    @break
                                @endforeach
                            </div>
                            <div class="col-8 col-md-8">
                                <h5 class="pt-0"><a href="{{ $content->slug }}">{{ $content->name }}</a></h5>
                            </div>
                        </div>
                    </div>
                @endforeach
        </div>
        @foreach($home_events['Contents']->skip(4)->take(1) as $event)
        <div class="col-md-4 mb-4 ">
            <div class="news-card">
                @foreach ($event['upload'] as $item)
                    <a href="{{ $event['slug'] }}">
                        <img class="img-fluid" src="{{ asset( 'images/uploads/large/'.$item['file']) }}" alt="{{ $item['name'] }}">  
                    </a>
                    @break
                @endforeach
                <div class="news-card-body">
                    <h5 class="card-title">{{ $event['name'] }}</h5>
                </div>
            </div>
        </div>
        @endforeach
    </div>
  </div>
</section>

@include('blog.ads.event') 
@endif