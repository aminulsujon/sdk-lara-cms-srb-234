
@if(!empty($tops))
<div class="trending-area fix mt-4">
    <div class="container">
        <div class="trending-main">
                <div class="row">
                    <div class="col-lg-8">
                        <!-- Trending Top -->
                        <div class="trending-top">
                            <div class="trend-top-img">
                                @foreach ($tops->Contents[0]['upload'] as $item)
                                    <a href="{{ $tops->Contents[0]['slug'] }}">
                                        <img class="img-fluid" src="{{ asset( 'images/uploads/large/'.$item['file']) }}" alt="{{ $item['name'] }}">  
                                    </a>
                                    @break
                                @endforeach
                                <div class="trend-top-cap rounded-bottom">
                                    <h2><a href="{{ $tops->Contents[0]['slug'] }}">{{ $tops->Contents[0]['name'] }}</a></h2>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Right content -->
                    <div class="col-lg-4">
                        @foreach($tops->Contents->skip(1)->take(4) as $content)
                            <a href="{{ $content->slug }}" class="w-100 text-decoration-none d-inline-flex align-items-end @if (!$loop->last) border-bottom pb-4 mb-3 @else pb-4 @endif">
                                <span class="fw-bold">{{ $content->name }}</span>  
                                @if(!empty($content['upload']) && count($content['upload']) > 0)
                                    @foreach ($content['upload']->take(1) as $item)
                                        <img 
                                            class="rounded w-25 ml-4"
                                                src="{{ asset( 'images/uploads/thumb/'.$item['file']) }}"
                                                alt="{{ $item['name'] }}"
                                            >
                                    @endforeach
                                @endif
                            </a>
                        @endforeach
                    </div>
                </div>

                {{-- <div class="row"> --}}
                <!-- Trending Bottom -->
                <div class="trending-bottom border-top pt-4">
                    <div class="row">
                        @foreach($tops->Contents->skip(4)->take(4) as $content)
                            <div class="col-6 col-md-3">
                                <div class="single-bottom mb-35 @if(!$loop->last) border-right pr-4 @endif">
                                    <div class="mb-4">
                                        @foreach ($content['upload'] as $item)
                                            <a href="{{ $content['slug'] }}">
                                                <img class="img-fluid" src="{{ asset( 'images/uploads/large/'.$item['file']) }}" alt="{{ $item['name'] }}">  
                                            </a>
                                            @break
                                        @endforeach
                                    </div>
                                    @php
// dd(date('d M Y h:i A', strtotime($content->created_at)));
                                    @endphp
                                    <div class="trend-bottom-cap">
                                        <h4><a class="font-weight-bold" href="{{ $content->slug }}">{{ $content->name }}</a></h4>
                                        <time class="text-muted">@include($websettings['cms_layout'].'.com_times_ago')</time>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
                {{-- </div> --}}

                <div class="trending-bottom">
                    <div class="row">
                        @foreach($tops->Contents->skip(9)->take(4) as $content)
                            <div class="col-6 col-md-3">
                                <div class="single-bottom mb-35 @if(!$loop->last) border-right pr-4 @endif">
                                    <div class="trend-bottom-cap">
                                        <h4><a class="font-weight-bold" href="{{ $content->slug }}">{{ $content->name }}</a></h4>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
        </div>
    </div>
</div>

@endif