<div class="border p-2 d-flex justify-content-center align-items-center m-auto" style="width:{{ $width }}px;height:{{ $height }}px;">
    {{ $position ?? 'position' }}
    <br>
    {{ $text ?? 'advertisement' }}
</div>