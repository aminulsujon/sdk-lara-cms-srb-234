# Allow all crawlers
User-agent: *
Disallow:

Sitemap: https://demo.dainikcoxsbazar.com/sitemap.xml